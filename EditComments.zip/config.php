<?php
$LIBRAIRY_NAME="ITK";
$GITORIOUS_PATH="http://gitorious.org/kitware/itk";
$DOXYGEN_URL="http://www.itk.org/Doxygen318/html";
$FOLDERS="Algorithms;BasicFilters;Common;IO;Numerics;Review;SpatialObject";
?>


