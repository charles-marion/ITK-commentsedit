// brush: "plain" aliases: ["text"]

//	This file is part of the "jQuery.Syntax" project, and is licensed under the GNU AGPLv3.
//	Copyright 2010 Samuel Williams. All rights reserved.
//	See <jquery.syntax.js> for licensing details.

Syntax.register('plain', function(brush) {
	brush.push(Syntax.lib.webLink);
});

